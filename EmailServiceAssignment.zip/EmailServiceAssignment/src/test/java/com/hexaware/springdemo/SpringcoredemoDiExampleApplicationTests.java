package com.hexaware.springdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcoredemoDiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
