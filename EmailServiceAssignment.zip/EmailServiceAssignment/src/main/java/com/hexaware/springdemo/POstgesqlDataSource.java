package com.hexaware.springdemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("postgesqlDataSource")
@Primary
public class POstgesqlDataSource implements IDataSource {

	@Override
	public void returnConnection() {
		System.out.println("Inside postgesqlDataSource");

	}

}
