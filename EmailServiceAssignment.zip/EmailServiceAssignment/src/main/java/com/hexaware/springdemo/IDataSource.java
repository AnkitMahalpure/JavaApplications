package com.hexaware.springdemo;

public interface IDataSource {
	public void returnConnection();
}
