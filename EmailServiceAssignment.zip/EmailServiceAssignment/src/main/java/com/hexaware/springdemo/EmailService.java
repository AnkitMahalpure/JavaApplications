package com.hexaware.springdemo;

import org.springframework.stereotype.Component;

@Component
public class EmailService {
	IDataSource dataSource;
	
	public EmailService(IDataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void sendEmail() {
		dataSource.returnConnection();
	}
}
