package com.hexaware.springdemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mysqlDataSource")

public class MYsqlDataSource implements IDataSource {

	@Override
	public void returnConnection() {
		System.out.println("Inside  mysqlDataSource");
	}

}
