package com.hexaware.dao;

import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexception.AccountNumberInvalidException;
import com.hexaware.myexception.InsufficientFundsException;
import com.hexaware.myexception.NegativeAmountException;

public class ServiceProviderImpl implements IServiceProvider {
	private Bank myBank;

	public ServiceProviderImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceProviderImpl(Bank myBank) {
		super();
		this.myBank = myBank;
	}

	@Override
	public BankAccount searchAccount(long accountNumber) throws AccountNumberInvalidException {
		BankAccount reqAccount = null;
		for (BankAccount account : myBank.getAccountList()) {
			if (account.getAccountNumber() == accountNumber) {
				reqAccount = account;
				break;
			}
		}
		if (reqAccount == null) {
			throw new AccountNumberInvalidException("Account Number Does not exists");
		}
		return reqAccount;

	}

	@Override
	public double checkbalance(long accountNumber) throws AccountNumberInvalidException {
		// TODO Auto-generated method stub
		double balanceAmount = -1;
		BankAccount reqAccount = null;
		reqAccount = searchAccount(accountNumber);
		balanceAmount = reqAccount.getBalance();
		return balanceAmount;
	}

	@Override
	public boolean deposit(long accountNumber, double amount) throws AccountNumberInvalidException, InsufficientFundsException {
		// TODO Auto-generated method stub
		BankAccount reqAccount = null;
		boolean depostStatus = false;
		if (amount > 0) {
			reqAccount = searchAccount(accountNumber);
			if (reqAccount == null) {
				throw new AccountNumberInvalidException("Account number not exists");
			}
			else {
				reqAccount.setBalance(reqAccount.getBalance() + amount);
				depostStatus = true;
			}
		}
		else {
			throw new InsufficientFundsException("Amount must be greater than 0");
		}
		return depostStatus;
	}

	@Override
	public boolean withdraw(long accountNumber, double amount)
			throws InsufficientFundsException, NegativeAmountException, AccountNumberInvalidException {
		BankAccount reqAccount = null;
		boolean withdrawStatus = false;
		reqAccount = searchAccount(accountNumber);
		if (reqAccount.getBalance() < amount) {
			throw new InsufficientFundsException("Insufficient funds...");
		}
		if (amount < 0) {
			throw new NegativeAmountException("Invalid amount.....");
		} else {
			reqAccount.setBalance(reqAccount.getBalance() - amount);
			withdrawStatus = true;
		}
		return withdrawStatus;
	}

	@Override
	public boolean createAccount(BankAccount newAcc) {
		// TODO Auto-generated method stub
		BankAccount lastAccObj = null;
		boolean status = false;
		myBank.getAccountList().add(newAcc);
		status = true;
		return status;
	}

	@Override
	public boolean removeAccount(long accountNumber) throws AccountNumberInvalidException {
		// TODO Auto-generated method stub
		BankAccount reqAccount = null;
		boolean removeStatus = false;
		reqAccount = searchAccount(accountNumber);
		this.myBank.getAccountList().remove(reqAccount);
		removeStatus = true;
		return removeStatus;
	}

}