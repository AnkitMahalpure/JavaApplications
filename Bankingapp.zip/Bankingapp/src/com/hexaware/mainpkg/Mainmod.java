package com.hexaware.mainpkg;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexception.AccountNumberInvalidException;
import com.hexaware.myexception.InsufficientFundsException;
import com.hexaware.myexception.NegativeAmountException;

public class Mainmod {
	private static final Logger LOGGER = Logger.getLogger(Mainmod.class.getName());

	public static void main(String[] args) {
		LOGGER.info("Inside Main Method");
		BankAccount b1 = new BankAccount("Ankit", "Saving", 10000.00);
		BankAccount b2 = new BankAccount("Aniket", "Current", 20000.00);
		BankAccount b3 = new BankAccount("Shubham", "Saving", 35000.00);

		ArrayList<BankAccount> list = new ArrayList<BankAccount>();
		list.add(b1);
		list.add(b2);
		list.add(b3);

		Bank b = new Bank("Hexa", list);

		System.out.println(b);

		ServiceProviderImpl myserviceobj = new ServiceProviderImpl(b);

		try {
			LOGGER.info("Inside checkbalance Method");
			System.out.println("Balance of account 1111 :" + myserviceobj.checkbalance(1113));
			LOGGER.info("Outside checkbalance Method");
		} catch (AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			LOGGER.warning("Error in checkbalance Method"+e.getMessage());
			//e.printStackTrace();
		}
		try {
			LOGGER.info("Inside checkbalance Method");
			System.out.println("Status of deposite :" + myserviceobj.deposit(1111, 500));
			LOGGER.info("Outside checkbalance Method");
		} catch (AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			LOGGER.warning("Inside checkbalance Method"+e.getMessage());
			//e.printStackTrace();
		} catch (InsufficientFundsException e) {
			// TODO Auto-generated catch block
			LOGGER.warning("Error Inside deposit Method" + e.getMessage());
			e.printStackTrace();
		}
		try {
			LOGGER.info("Inside checkbalance Method");
			System.out.println("Balance of account 1111 :" + myserviceobj.checkbalance(1511));
			LOGGER.info("Outside checkbalance Method");
		} catch (AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			LOGGER.warning("Error in checkbalance Method" + e.getMessage());

		}
		try {
			LOGGER.info("Inside withdraw Method");
			System.out.println("Status of withdraw :" + myserviceobj.withdraw(1112, 5000));
			LOGGER.info("Outside withdraw Method");
		} catch (InsufficientFundsException | NegativeAmountException | AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			LOGGER.warning("Error in removeAccount Method" + e.getMessage());
		}
		try {
			LOGGER.info("Inside checkbalance Method");
			System.out.println("Balance of account 1112 :" + myserviceobj.checkbalance(1112));
			LOGGER.info("Outside checkbalance Method");
		} catch (AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			LOGGER.warning("Error in checkBalance Method" + e.getMessage());
		}
		System.out.println("New Account status :" + myserviceobj.createAccount(new BankAccount("Sachin", "Current", 100000)));
		System.out.println(b);
		try {
			System.out.println("Remove account status :" + myserviceobj.removeAccount(1110));
		} catch (AccountNumberInvalidException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			LOGGER.warning("Error in removeAccount Method" + e.getMessage());
		}
		System.out.println(b);

		LOGGER.info("Outside Main Method");
	}
}
