public class StringSearchEngine {

    private String originalText;

    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    public void findAndPrintOccurrences(String substring) {
        int index = 0;
        while ((index = originalText.indexOf(substring, index)) != -1) {
            System.out.println("Found at index: " + index);
            index += substring.length();
        }
    }

    public String highlightMatches(String substring) {
        StringBuilder highlightedText = new StringBuilder(originalText);
        int index = 0;

        while ((index = originalText.indexOf(substring, index)) != -1) {
            highlightedText.insert(index, "["); // Add opening highlight bracket
            index += substring.length() + 1;    // Move index to the end of the highlighted substring
            highlightedText.insert(index, "]"); // Add closing highlight bracket
            index += 1;                          // Move index to continue searching
        }

        return highlightedText.toString();
    }
}