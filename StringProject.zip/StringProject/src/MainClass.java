import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainClass {
	public static void main(String[] args) {
		String email = "test@example.com"; // Replace with the email address you want to validate
        if (isValidEmail(email)) {
            System.out.println(email + " is a valid email address.");
        } else {
            System.out.println(email + " is not a valid email address.");
        }
        
        URLBuilder urlBuilder = new URLBuilder();

        String builtUrl = urlBuilder
                .setProtocol("https")
                .setHost("www.example.com")
                .setPath("/path/to/resource")
                .addQueryParam("param1", "value1")
                .addQueryParam("param2", "value2")
                .build();

        System.out.println("Built URL: " + builtUrl);
        
        
        String urlString = "https://www.example.com/path/to/resource?param1=value1&param2=value2";
        URLParser urlParser = new URLParser(urlString);

        System.out.println("Protocol: " + urlParser.getProtocol());
        System.out.println("Host: " + urlParser.getHost());
        System.out.println("Path: " + urlParser.getPath());
        System.out.println("Query Parameters: " + urlParser.getQueryParameters());
        
        String originalText = "This is a sample text for searching. Searching is fun!";
        StringSearchEngine searchEngine = new StringSearchEngine(originalText);

        // Find and print all occurrences of a substring
        System.out.println("Occurrences of 'search':");
        searchEngine.findAndPrintOccurrences("search");

        // Highlight matched substrings in the original text
        String highlightedText = searchEngine.highlightMatches("search");
        System.out.println("\nHighlighted Text:");
        System.out.println(highlightedText);
        
        CustomStringBuilder customStringBuilder = new CustomStringBuilder("Hello, ");

        // Append a string
        customStringBuilder.append("world!");
        System.out.println("After appending: " + customStringBuilder);

        // Insert a string at a specific index
        customStringBuilder.insert(7, "awesome ");
        System.out.println("After inserting: " + customStringBuilder);

        // Delete a portion of the string
        customStringBuilder.delete(0, 7);
        System.out.println("After deleting: " + customStringBuilder);
    }
	 public static boolean isValidEmail(String email) {
	        // Define the regular expression for a valid email address
	        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	        
	        // Create a Pattern object
	        Pattern pattern = Pattern.compile(emailRegex);
	        
	        // Create a Matcher object
	        Matcher matcher = pattern.matcher(email);
	        
	        // Return true if the email matches the pattern, false otherwise
	        return matcher.matches();
	    }
}
