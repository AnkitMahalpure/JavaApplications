import java.util.HashMap;
import java.util.Map;

public class URLParser {
	private String url;

	public URLParser(String url) {
		this.url = url;
	}

	public String getProtocol() {
		int colonIndex = url.indexOf(':');
		return url.substring(0, colonIndex);
	}

	public String getHost() {
		int doubleSlashIndex = url.indexOf("//");
		int pathIndex = url.indexOf('/', doubleSlashIndex + 2);
		if (pathIndex == -1) {
			return url.substring(doubleSlashIndex + 2);
		} else {
			return url.substring(doubleSlashIndex + 2, pathIndex);
		}
	}

	public String getPath() {
		int doubleSlashIndex = url.indexOf("//");
		int pathIndex = url.indexOf('/', doubleSlashIndex + 2);
		if (pathIndex == -1) {
			return "";
		} else {
			int queryIndex = url.indexOf('?', pathIndex);
			if (queryIndex == -1) {
				return url.substring(pathIndex);
			} else {
				return url.substring(pathIndex, queryIndex);
			}
		}
	}

	public Map<String, String> getQueryParameters() {
		Map<String, String> queryParams = new HashMap<>();
		int queryIndex = url.indexOf('?');
		if (queryIndex != -1) {
			String queryString = url.substring(queryIndex + 1);
			String[] pairs = queryString.split("&");
			for (String pair : pairs) {
				String[] keyValue = pair.split("=");
				if (keyValue.length == 2) {
					queryParams.put(keyValue[0], keyValue[1]);
				}
			}
		}
		return queryParams;
	}
}
