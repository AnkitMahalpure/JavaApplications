public class CustomStringBuilder {

	private char[] content;
	private int size;

	public CustomStringBuilder() {
		content = new char[16]; // Initial capacity
		size = 0;
	}

	public CustomStringBuilder(String initial) {
		content = new char[initial.length() + 16];
		size = 0;
		append(initial);
	}

	public void append(String str) {
		ensureCapacity(size + str.length());
		str.getChars(0, str.length(), content, size);
		size += str.length();
	}

	public void insert(int index, String str) {
		ensureCapacity(size + str.length());
		System.arraycopy(content, index, content, index + str.length(), size - index);
		str.getChars(0, str.length(), content, index);
		size += str.length();
	}

	public void delete(int start, int end) {
		if (start < 0 || end > size || start >= end) {
			throw new IndexOutOfBoundsException();
		}
		System.arraycopy(content, end, content, start, size - end);
		size -= (end - start);
	}

	private void ensureCapacity(int minimumCapacity) {
		if (minimumCapacity > content.length) {
			int newCapacity = Math.max(content.length * 2, minimumCapacity);
			char[] newArray = new char[newCapacity];
			System.arraycopy(content, 0, newArray, 0, size);
			content = newArray;
		}
	}

	public String toString() {
		return new String(content, 0, size);
	}
}