import java.util.ArrayList;
import java.util.List;

public class Hospital {
	List<Doctor> doctors;
	
	public Hospital() {
		doctors=new ArrayList<Doctor>();
	}
	
	public void addDoctor(Doctor d1) {
		doctors.add(d1);
	}
	
	public void displayDoctor() {
		for (Doctor doctor : doctors) {
			System.out.println(doctor.name+","+doctor.department);
		}
	}
}
