
public class Doctor {
	public int doctorID;
	public String department;
	public String name;
	public int age;
	
	
	public Doctor(int doctorID, String department, String name, int age) {
		this.doctorID = doctorID;
		this.department = department;
		this.name = name;
		this.age = age;
	}
	
	
	
}
